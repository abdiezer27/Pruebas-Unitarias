
# tests/test_calculadora.py
import pytest
from app.calculadora import suma, division

# Caso de Uso 1: Pruebas para la función suma
def test_suma_positivos():
    """Prueba la suma de números positivos."""
    assert suma(5, 3) == 8

def test_suma_negativos():
    """Prueba la suma de números negativos."""
    assert suma(-2, -4) == -6

def test_suma_mixtos():
    """Prueba la suma de números positivos y negativos."""
    assert suma(-2, 5) == 3

# Caso de Uso 2: Pruebas para la función división
def test_division_valida():
    """Prueba la división de dos números."""
    assert division(10, 2) == 5.0

def test_division_negativos():
    """Prueba la división de números negativos."""
    assert division(-10, -2) == 5.0

def test_division_por_cero():
    """Prueba la división por cero (debe lanzar ValueError)."""
    with pytest.raises(ValueError, match="No se puede dividir entre cero"):
        division(10, 0)
